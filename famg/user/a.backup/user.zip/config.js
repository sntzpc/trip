// CONFIGURASI AMAN - Aplikasi Famili Gathering KMP1 2026
// File ini berisi konfigurasi yang dapat diubah dengan aman
// Tanpa perlu mengubah kode utama aplikasi

const AppConfig = {
    // KONFIGURASI ACARA
    event: {
        // Nama acara
        name: "Famili Gathering KMP1 Tahun 2026",
        
        // Tanggal dan waktu acara utama (Gala Dinner)
        // Format: "YYYY-MM-DDTHH:mm:ss±HH:mm"
        galaDinnerDate: "2026-01-18T16:00:00+07:00",
        galaDinnerEndTime: "2026-01-18T22:00:00+07:00",
        
        // Tanggal rangkaian acara
        eventStartDate: "2026-01-16T00:00:00+07:00",
        eventEndDate: "2026-01-19T23:59:59+07:00",
        
        // Lokasi acara utama
        location: {
            name: "Seriang Training Center",
            address: "Desa Kekurak Kecamatan Badau",
            
            // Koordinat geofencing (titik pusat)
            coordinates: {
                latitude: 0.964055,   // Latitude Novotel Pontianak
                longitude: 111.893026, // Longitude Novotel Pontianak
                accuracy: 50           // Akurasi dalam meter
            },
            
            // Radius geofencing dalam meter
            geofencingRadius: 250
        }
    },
    
    // KONFIGURASI APLIKASI
    app: {
        // Waktu timeout untuk konfirmasi doorprize (dalam milidetik)
        doorprizeConfirmTimeout: 60000, // 1 menit
        
        // Interval update lokasi (dalam milidetik)
        locationUpdateInterval: 30000, // 30 detik
        
        // Interval pergantian acara (simulasi, dalam milidetik)
        eventSwitchInterval: 180000, // 3 menit
        
        // Waktu notifikasi (dalam milidetik)
        notificationTimeout: 5000
    },
    
    // KONFIGURASI KEAMANAN
    security: {
        // Validasi NIK (minimal panjang karakter)
        nikMinLength: 8,
        
        // Validasi tanggal dan waktu
        enableDateValidation: true,
        enableGeofencing: true,
        
        // Mode debug (untuk pengembangan)
        debugMode: false
    },
    
    // KONFIGURASI TAMPILAN
    ui: {
        primaryColor: "#3B82F6",    // Biru
        secondaryColor: "#10B981",  // Hijau
        accentColor: "#8B5CF6",     // Ungu
        successColor: "#10B981",    // Hijau sukses
        errorColor: "#EF4444",      // Merah error
        warningColor: "#F59E0B"     // Kuning peringatan
    },
    
    // METODE UNTUK MENGAMBIL KONFIGURASI
    getEventDate: function() {
        return new Date(this.event.galaDinnerDate);
    },

    // Di dalam AppConfig object, tambahkan:
    colors: {
        day1: {
            primary: '#3B82F6', // Biru
            light: '#EFF6FF'
        },
        day2: {
            primary: '#10B981', // Hijau
            light: '#F0FDF4'
        },
        day3: {
            primary: '#8B5CF6', // Ungu
            light: '#FAF5FF'
        },
        day4: {
            primary: '#F97316', // Oranye
            light: '#FFF7ED'
        }
    },
    
    getEventLocation: function() {
        return {
            lat: this.event.location.coordinates.latitude,
            lng: this.event.location.coordinates.longitude,
            radius: this.event.location.geofencingRadius,
            name: this.event.location.name,
            address: this.event.location.address
        };
    },
    
    // Validasi apakah tanggal saat ini adalah tanggal acara
    isValidEventDate: function(dateToCheck = new Date()) {
        if (!this.security.enableDateValidation) return true;
        
        const eventDate = new Date(this.event.galaDinnerDate);
        const eventStart = new Date(this.event.eventStartDate);
        const eventEnd = new Date(this.event.eventEndDate);
        
        return dateToCheck >= eventStart && dateToCheck <= eventEnd;
    },
    
    // Validasi apakah waktu saat ini dalam jam Gala Dinner
    isValidGalaDinnerTime: function(dateToCheck = new Date()) {
        if (!this.security.enableDateValidation) return true;
        
        const galaStart = new Date(this.event.galaDinnerDate);
        const galaEnd = new Date(this.event.galaDinnerEndTime);
        
        return dateToCheck >= galaStart && dateToCheck <= galaEnd;
    },
    
    // Debug logging (hanya di mode debug)
    log: function(message, data = null) {
        if (this.security.debugMode) {
            console.log(`[AppConfig] ${message}`, data || '');
        }
    }
};

// Object beku agar tidak bisa diubah secara tidak sengaja
Object.freeze(AppConfig);
Object.freeze(AppConfig.event);
Object.freeze(AppConfig.event.location);
Object.freeze(AppConfig.event.location.coordinates);
Object.freeze(AppConfig.app);
Object.freeze(AppConfig.security);
Object.freeze(AppConfig.ui);

// Ekspor untuk penggunaan di modul lain
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AppConfig;
}