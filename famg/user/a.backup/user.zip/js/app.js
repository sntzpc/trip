// Main Application
class App {
    constructor() {
        this.initialize();
    }

    initialize() {
        console.log('Famili Gathering KMP1 2026 App initialized');
        
        // Cek apakah user sudah absen
        this.checkInitialState();
        
        // Event listeners tambahan
        this.addEventListeners();
    }

    checkInitialState() {
        // Jika user sudah login dari session, langsung tampilkan app
        const savedUser = sessionStorage.getItem('currentUser');
        if (savedUser) {
            // User sudah login, aplikasi akan ditampilkan oleh auth module
            console.log('User already logged in');
        }
    }

    addEventListeners() {
        // Tambahkan event listener untuk menguji doorprize (hanya untuk development)
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
            document.addEventListener('keydown', (e) => {
                // Ctrl+Shift+D untuk draw doorprize (development only)
                if (e.ctrlKey && e.shiftKey && e.key === 'D') {
                    e.preventDefault();
                    doorprize.drawWinner();
                    utils.showNotification('Doorprize diundi secara manual (development mode)', 'info');
                }
                
                // Ctrl+Shift+E untuk ganti event (development only)
                if (e.ctrlKey && e.shiftKey && e.key === 'E') {
                    e.preventDefault();
                    const nextEventIndex = Math.floor(Math.random() * events.events.length);
                    events.setCurrentEvent(events.events[nextEventIndex]);
                    utils.showNotification('Acara diganti secara manual (development mode)', 'info');
                }
            });
        }
    }
}

// Inisialisasi aplikasi saat DOM siap
document.addEventListener('DOMContentLoaded', () => {
    new App();
});