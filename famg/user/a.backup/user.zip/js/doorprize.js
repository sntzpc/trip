// Doorprize Module dengan Audio Lokal
class Doorprize {
    constructor() {
        this.winners = [];
        this.prizes = [
            { id: 1, name: 'Smart TV 55"', image: 'tv.png' },
            { id: 2, name: 'Smartphone Flagship', image: 'phone.png' },
            { id: 3, name: 'Laptop Premium', image: 'laptop.png' },
            { id: 4, name: 'Paket Liburan', image: 'holiday.png' },
            { id: 5, name: 'Voucher Belanja 5 Juta', image: 'voucher.png' },
            { id: 6, name: 'Kulkas 2 Pintu', image: 'fridge.png' },
            { id: 7, name: 'Mesin Cuci', image: 'washing.png' },
            { id: 8, name: 'Sepeda Listrik', image: 'bike.png' }
        ];
        
        this.audioContext = null;
        this.isAudioInitialized = false;
        
        this.initializeElements();
        this.initializeAudio();
        this.loadWinners();
    }

    initializeElements() {
        this.doorprizeContainer = document.getElementById('doorprize-container');
        this.doorprizeSound = document.getElementById('doorprize-sound');
    }

    // Inisialisasi audio system
    initializeAudio() {
        // Preload audio file
        if (this.doorprizeSound) {
            this.doorprizeSound.load();
            
            // Tambahkan event listener untuk error handling
            this.doorprizeSound.addEventListener('error', (e) => {
                console.warn('Audio file error, using fallback sound:', e);
                this.isAudioInitialized = false;
            });
            
            this.doorprizeSound.addEventListener('canplaythrough', () => {
                console.log('Audio file ready to play');
                this.isAudioInitialized = true;
            });
        }
        
        // Coba inisialisasi Web Audio API untuk fallback
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
                this.audioContext = new AudioContext();
                console.log('Web Audio API initialized');
            }
        } catch (e) {
            console.log('Web Audio API not available:', e);
        }
    }

    drawWinner() {
        // Cek apakah dalam radius lokasi untuk pengundian
        if (!utils.checkLocation()) {
            utils.showNotification('Tidak dapat mengundi doorprize', 'Pengundian hanya dapat dilakukan dalam radius acara');
            return;
        }
        
        // Dapatkan peserta yang hadir
        const participants = this.getAttendedParticipants();
        if (participants.length === 0) {
            utils.showNotification('Belum ada peserta yang hadir', 'warning');
            return;
        }
        
        // Dapatkan hadiah yang belum diambil
        const availablePrizes = this.prizes.filter(prize => 
            !this.winners.some(winner => winner.prizeId === prize.id && winner.confirmed)
        );
        
        if (availablePrizes.length === 0) {
            utils.showNotification('Semua doorprize sudah diambil', 'info');
            return;
        }
        
        // Acak pemenang
        const randomParticipant = participants[Math.floor(Math.random() * participants.length)];
        const randomPrize = availablePrizes[Math.floor(Math.random() * availablePrizes.length)];
        
        // Buat pemenang baru
        const winner = {
            id: utils.generateId(),
            nik: randomParticipant.nik,
            name: randomParticipant.name,
            prizeId: randomPrize.id,
            prizeName: randomPrize.name,
            prizeImage: randomPrize.image,
            timestamp: new Date().toISOString(),
            confirmed: false,
            expired: false
        };
        
        // Tambahkan ke daftar pemenang
        this.winners.push(winner);
        this.saveWinners();
        
        // Tampilkan pemenang
        this.displayWinner(winner);
        
        // Putar suara notifikasi
        this.playNotificationSound();
        
        // Timer untuk konfirmasi (1 menit)
        setTimeout(() => {
            if (!winner.confirmed && !winner.expired) {
                winner.expired = true;
                this.updateWinnerDisplay(winner.id);
                
                // Acak ulang setelah 30 detik
                setTimeout(() => {
                    this.drawWinner();
                }, 30000);
            }
        }, 60000); // 1 menit
        
        utils.showNotification(`Doorprize untuk ${randomPrize.name} telah diundi!`, 'success');
    }

    getAttendedParticipants() {
        const participants = [];
        
        // Dapatkan semua data kehadiran dari localStorage
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('attendance_')) {
                const attendanceData = JSON.parse(localStorage.getItem(key));
                participants.push({
                    nik: attendanceData.nik,
                    name: attendanceData.name
                });
            }
        }
        
        return participants;
    }

    displayWinner(winner) {
        // Sembunyikan "no winner" message jika ada
        const noWinnerElement = document.getElementById('no-winner');
        if (noWinnerElement) {
            noWinnerElement.classList.add('hidden');
        }
        
        // Buat elemen pemenang
        const winnerElement = document.createElement('div');
        winnerElement.id = `winner-${winner.id}`;
        winnerElement.className = 'doorprize-winner p-4 border-2 border-yellow-300 bg-yellow-50 rounded-xl animate-fade-in';
        winnerElement.innerHTML = `
            <div class="flex items-start">
                <div class="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center mr-4">
                    <i class="fas fa-gift text-white text-xl"></i>
                </div>
                <div class="flex-grow">
                    <h4 class="font-bold text-gray-800">${winner.name}</h4>
                    <p class="text-gray-600 text-sm">NIK: ${winner.nik}</p>
                    <div class="mt-2 flex items-center">
                        <div class="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded flex items-center justify-center mr-2">
                            <i class="fas fa-trophy text-white text-sm"></i>
                        </div>
                        <span class="font-semibold text-gray-800">${winner.prizeName}</span>
                    </div>
                </div>
                <div class="ml-4">
                    <button class="confirm-prize-btn bg-gradient-to-r from-green-500 to-teal-500 text-white px-4 py-2 rounded-lg font-medium hover:opacity-90 transition disabled:opacity-50 disabled:cursor-not-allowed" data-winner-id="${winner.id}">
                        <i class="fas fa-check mr-2"></i>Ambil
                    </button>
                </div>
            </div>
            <div class="mt-3 text-xs text-gray-500">
                <i class="far fa-clock mr-1"></i>Konfirmasi dalam 1 menit
            </div>
        `;
        
        // Tambahkan ke container
        this.doorprizeContainer.prepend(winnerElement);
        
        // Tambahkan event listener untuk tombol konfirmasi
        const confirmBtn = winnerElement.querySelector('.confirm-prize-btn');
        confirmBtn.addEventListener('click', () => this.confirmPrize(winner.id));
        
        // Cek apakah user adalah pemenang
        const currentUser = JSON.parse(sessionStorage.getItem('currentUser') || 'null');
        if (currentUser && currentUser.nik === winner.nik) {
            utils.showNotification(`Selamat! Anda memenangkan ${winner.prizeName}`, 'success');
        }
    }

    async confirmPrize(winnerId) {
        const winner = this.winners.find(w => w.id === winnerId);
        if (!winner) return;
        
        // Cek apakah dalam radius lokasi
        const inLocation = await utils.checkLocation();
        if (!inLocation) {
            utils.showNotification('Tidak dapat mengambil hadiah', 'Anda berada di luar radius lokasi acara');
            return;
        }
        
        // Konfirmasi hadiah
        winner.confirmed = true;
        winner.confirmedAt = new Date().toISOString();
        this.saveWinners();
        
        // Update tampilan
        this.updateWinnerDisplay(winnerId);
        
        // Putar suara konfirmasi
        this.playSuccessSound();
        
        utils.showNotification(`Hadiah berhasil dikonfirmasi oleh ${winner.name}`, 'success');
    }

    updateWinnerDisplay(winnerId) {
        const winnerElement = document.getElementById(`winner-${winnerId}`);
        if (!winnerElement) return;
        
        const winner = this.winners.find(w => w.id === winnerId);
        if (!winner) return;
        
        const confirmBtn = winnerElement.querySelector('.confirm-prize-btn');
        
        if (winner.confirmed) {
            winnerElement.className = 'doorprize-winner confirmed p-4 border-2 border-green-300 bg-green-50 rounded-xl';
            confirmBtn.innerHTML = '<i class="fas fa-check-circle mr-2"></i>Diambil';
            confirmBtn.className = 'bg-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium cursor-not-allowed';
            confirmBtn.disabled = true;
            
            // Update status text
            const statusText = winnerElement.querySelector('.text-gray-500');
            if (statusText) {
                statusText.innerHTML = '<i class="fas fa-check-circle text-green-500 mr-1"></i>Hadiah telah diambil';
                statusText.className = 'mt-3 text-xs text-green-600';
            }
        } else if (winner.expired) {
            winnerElement.className = 'doorprize-winner expired p-4 border-2 border-red-300 bg-red-50 rounded-xl';
            confirmBtn.innerHTML = '<i class="fas fa-times-circle mr-2"></i>Kadaluarsa';
            confirmBtn.className = 'bg-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium cursor-not-allowed';
            confirmBtn.disabled = true;
            
            // Update status text
            const statusText = winnerElement.querySelector('.text-gray-500');
            if (statusText) {
                statusText.innerHTML = '<i class="fas fa-times-circle text-red-500 mr-1"></i>Waktu konfirmasi habis';
                statusText.className = 'mt-3 text-xs text-red-600';
            }
            
            // Hapus dari tampilan setelah 5 detik
            setTimeout(() => {
                if (winnerElement.parentElement) {
                    winnerElement.remove();
                }
                
                // Tampilkan "no winner" jika tidak ada pemenang lain
                const winnersDisplayed = this.doorprizeContainer.querySelectorAll('.doorprize-winner').length;
                if (winnersDisplayed === 0) {
                    const noWinnerElement = document.getElementById('no-winner');
                    if (noWinnerElement) {
                        noWinnerElement.classList.remove('hidden');
                    }
                }
            }, 5000);
        }
    }

    // Method utama untuk memutar suara notifikasi
    playNotificationSound() {
        // Coba putar file audio MP3 terlebih dahulu
        if (this.doorprizeSound && this.isAudioInitialized) {
            try {
                this.doorprizeSound.currentTime = 0;
                const playPromise = this.doorprizeSound.play();
                
                if (playPromise !== undefined) {
                    playPromise.catch(error => {
                        console.warn('MP3 audio play failed, using Web Audio API:', error);
                        this.playWebAudioNotification();
                    });
                }
            } catch (error) {
                console.warn('MP3 audio error, using Web Audio API:', error);
                this.playWebAudioNotification();
            }
        } else {
            // Jika file MP3 tidak tersedia, gunakan Web Audio API
            this.playWebAudioNotification();
        }
        
        // Trigger getar (jika didukung)
        this.vibrateDevice();
    }

    // Web Audio API untuk suara notifikasi
    playWebAudioNotification() {
        if (!this.audioContext) {
            // Coba buat AudioContext baru
            try {
                const AudioContext = window.AudioContext || window.webkitAudioContext;
                this.audioContext = new AudioContext();
            } catch (e) {
                console.log('Cannot create AudioContext:', e);
                return;
            }
        }
        
        // Pastikan context tidak suspended
        if (this.audioContext.state === 'suspended') {
            this.audioContext.resume();
        }
        
        try {
            // Buat oscillator untuk suara kemenangan
            const oscillator = this.audioContext.createOscillator();
            const gainNode = this.audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(this.audioContext.destination);
            
            // Pattern suara: naik-naik (C5 -> E5 -> G5)
            const now = this.audioContext.currentTime;
            
            oscillator.frequency.setValueAtTime(523.25, now);      // C5
            oscillator.frequency.setValueAtTime(659.25, now + 0.1); // E5
            oscillator.frequency.setValueAtTime(783.99, now + 0.2); // G5
            oscillator.frequency.setValueAtTime(1046.50, now + 0.3); // C6
            
            oscillator.type = 'sine';
            
            // Envelope volume
            gainNode.gain.setValueAtTime(0, now);
            gainNode.gain.linearRampToValueAtTime(0.3, now + 0.05);
            gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.8);
            
            oscillator.start(now);
            oscillator.stop(now + 0.8);
            
        } catch (error) {
            console.log('Web Audio API error:', error);
            // Fallback ke HTML5 Audio dengan data URL
            this.playSimpleBeep();
        }
    }

    // Suara sederhana untuk konfirmasi
    playSuccessSound() {
        if (this.audioContext) {
            try {
                const oscillator = this.audioContext.createOscillator();
                const gainNode = this.audioContext.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(this.audioContext.destination);
                
                const now = this.audioContext.currentTime;
                
                oscillator.frequency.setValueAtTime(880, now); // A5
                oscillator.type = 'triangle';
                
                gainNode.gain.setValueAtTime(0, now);
                gainNode.gain.linearRampToValueAtTime(0.2, now + 0.1);
                gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
                
                oscillator.start(now);
                oscillator.stop(now + 0.3);
                
            } catch (error) {
                console.log('Success sound error:', error);
            }
        }
    }

    // Fallback: suara beep sederhana
    playSimpleBeep() {
        try {
            // Buat audio element dengan data URL base64
            const audio = new Audio();
            
            // Base64 encoded WAV file sederhana (beep pendek)
            audio.src = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAZGF0YQQAAAAAAA==';
            audio.volume = 0.3;
            
            const playPromise = audio.play();
            if (playPromise !== undefined) {
                playPromise.catch(e => console.log('Simple beep failed:', e));
            }
        } catch (error) {
            console.log('All audio methods failed:', error);
        }
    }

    // Getar perangkat
    vibrateDevice() {
        if (navigator.vibrate) {
            // Pattern: pendek-panjang-pendek
            try {
                navigator.vibrate([100, 200, 100]);
            } catch (e) {
                console.log('Vibration failed:', e);
            }
        }
    }

    saveWinners() {
        localStorage.setItem('doorprize_winners', JSON.stringify(this.winners));
    }

    loadWinners() {
        const savedWinners = localStorage.getItem('doorprize_winners');
        if (savedWinners) {
            this.winners = JSON.parse(savedWinners);
            
            // Tampilkan pemenang yang sudah ada
            this.winners.forEach(winner => {
                if (!winner.expired || winner.confirmed) {
                    this.displayWinner(winner);
                    this.updateWinnerDisplay(winner.id);
                }
            });
        }
    }
}

// Inisialisasi doorprize module
const doorprize = new Doorprize();
window.doorprize = doorprize; // Agar bisa diakses dari modul lain