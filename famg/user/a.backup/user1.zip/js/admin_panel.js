/* ==========================
   FG2026 - Admin Panel
   Role: ADMIN
   ========================== */

(()=>{
  const $ = (s,r=document)=>r.querySelector(s);
  const $$ = (s,r=document)=>Array.from(r.querySelectorAll(s));
  const KEY = 'fg_admin_token_v1';
  let token = localStorage.getItem(KEY)||'';
  let me = null;

  function setBusy(on){
    const b = $('#btn-login');
    if(b) b.disabled = !!on;
  }

  function htmlEsc(s){
    return String(s??'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));
  }

  async function ensureMe(){
    if(!token) return null;
    try{
      const r = await FGAPI.auth.me(token);
      me = r.user;
      return me;
    }catch(e){
      token='';
      localStorage.removeItem(KEY);
      return null;
    }
  }

  function showLogin(){
    $('#login')?.classList.remove('hidden');
    $('#app')?.classList.add('hidden');
    $('#btn-logout')?.classList.add('hidden');
  }
  function showApp(){
    $('#login')?.classList.add('hidden');
    $('#app')?.classList.remove('hidden');
    $('#btn-logout')?.classList.remove('hidden');
  }

  async function doLogin(){
    const u = $('#username').value.trim();
    const p = $('#password').value;
    if(!u||!p){ utils.showNotification('Isi username & password','warning'); return; }
    setBusy(true);
    try{
      const data = await FGAPI.auth.login(u,p);
      token = data.token;
      localStorage.setItem(KEY, token);
      me = data.user;
      if(me.role !== 'ADMIN'){
        utils.showNotification('Akun ini bukan ADMIN','error');
        await FGAPI.auth.logout(token).catch(()=>{});
        token=''; localStorage.removeItem(KEY);
        showLogin();
        return;
      }
      utils.showNotification('Login berhasil','success');
      showApp();
      await loadAll();
    }catch(e){
      utils.showNotification(String(e.message||e),'error');
    }finally{ setBusy(false); }
  }

  async function doLogout(){
    if(token) await FGAPI.auth.logout(token).catch(()=>{});
    token=''; me=null; localStorage.removeItem(KEY);
    showLogin();
    utils.showNotification('Logout','info');
  }

  // ------- Tabs -------
  function bindTabs(){
    $$('.tab-btn').forEach(btn=>{
      btn.addEventListener('click',()=>{
        const tab = btn.dataset.tab;
        $$('.tab-btn').forEach(b=>b.className = 'tab-btn px-4 py-2 rounded-xl bg-gray-100');
        btn.className = 'tab-btn px-4 py-2 rounded-xl bg-blue-600 text-white';
        $$('.tab').forEach(t=>t.classList.add('hidden'));
        $('#tab-'+tab)?.classList.remove('hidden');
      });
    });
  }

  // ------- Render helpers -------
  function renderTable(container, cols, rows, actions){
    const head = cols.map(c=>`<th class="text-left p-2 text-xs uppercase tracking-wider text-gray-500">${htmlEsc(c.label)}</th>`).join('');
    const body = (rows||[]).map(r=>{
      const tds = cols.map(c=>`<td class="p-2 text-sm text-gray-700 whitespace-nowrap">${htmlEsc(r[c.key])}</td>`).join('');
      const act = actions ? `<td class="p-2 text-sm whitespace-nowrap">${actions(r)}</td>` : '';
      return `<tr class="border-t">${tds}${act}</tr>`;
    }).join('');
    container.innerHTML = `
      <div class="overflow-auto">
        <table class="min-w-full">
          <thead><tr>${head}${actions?'<th class="p-2"></th>':''}</tr></thead>
          <tbody>${body||''}</tbody>
        </table>
      </div>
    `;
  }

  // ------- Loaders -------
  let cache = { participants:[], events:[], prizes:[], users:[] };

  async function loadAll(){
    await Promise.all([loadParticipants(), loadEvents(), loadPrizes(), loadUsers(), renderControl()]);
  }

  async function loadParticipants(){
    const data = await FGAPI.admin.participantsList(token);
    cache.participants = data.items||[];
    const box = $('#tab-participants');
    box.innerHTML = `
      <div class="flex items-center justify-between gap-3 mb-4">
        <div>
          <h3 class="text-xl font-bold text-gray-800">Peserta</h3>
          <p class="text-gray-600 text-sm">Kelola master peserta & keluarga. Doorprize memakai peserta dengan <b>position=Staff</b>.</p>
        </div>
        <button id="p-add" class="bg-gradient-to-r from-blue-600 to-teal-500 text-white px-4 py-2 rounded-xl"><i class="fas fa-plus mr-2"></i>Tambah</button>
      </div>
    `;
    const tableWrap = document.createElement('div');
    box.appendChild(tableWrap);
    renderTable(tableWrap,
      [
        {key:'nik',label:'NIK'},
        {key:'name',label:'Nama'},
        {key:'position',label:'Jabatan'},
        {key:'department',label:'Dept'},
        {key:'family_count',label:'Keluarga'}
      ],
      cache.participants.map(x=>({
        nik:x.nik, name:x.name, position:x.position, department:x.department,
        family_count:(x.family||[]).length
      })),
      (r)=>`<button class="p-edit text-blue-700" data-nik="${htmlEsc(r.nik)}"><i class="fas fa-pen"></i></button>
            <button class="p-del text-red-600 ml-2" data-nik="${htmlEsc(r.nik)}"><i class="fas fa-trash"></i></button>`
    );

    $('#p-add').onclick = async ()=>{
      const nik = prompt('NIK?');
      if(!nik) return;
      const name = prompt('Nama?')||'';
      const position = prompt('Jabatan? (mis: Staff/Manager/Supervisor)')||'Staff';
      const department = prompt('Departemen?')||'';
      const family = prompt('Daftar keluarga (pisahkan dengan ; )\nContoh: Nama;Istri;Anak1')||name;
      const item = { nik:String(nik).trim(), name, position, department, family: family.split(';').map(s=>s.trim()).filter(Boolean) };
      await FGAPI.admin.participantsUpsert(token, item);
      utils.showNotification('Tersimpan','success');
      await loadParticipants();
    };

    $$('.p-edit', box).forEach(btn=>btn.onclick = async ()=>{
      const nik = btn.dataset.nik;
      const cur = cache.participants.find(x=>x.nik===nik);
      if(!cur) return;
      const name = prompt('Nama?', cur.name||'') ?? cur.name;
      const position = prompt('Jabatan?', cur.position||'') ?? cur.position;
      const department = prompt('Departemen?', cur.department||'') ?? cur.department;
      const family = prompt('Keluarga (pisahkan ;) ?', (cur.family||[]).join(';')) ?? (cur.family||[]).join(';');
      const item = { nik, name, position, department, family: String(family).split(';').map(s=>s.trim()).filter(Boolean) };
      await FGAPI.admin.participantsUpsert(token, item);
      utils.showNotification('Tersimpan','success');
      await loadParticipants();
    });

    $$('.p-del', box).forEach(btn=>btn.onclick = async ()=>{
      const nik = btn.dataset.nik;
      if(!confirm('Hapus peserta '+nik+'?')) return;
      await FGAPI.admin.participantsDelete(token, nik);
      utils.showNotification('Terhapus','info');
      await loadParticipants();
    });
  }

  async function loadEvents(){
    const data = await FGAPI.admin.eventsList(token);
    cache.events = data.items||[];
    const box = $('#tab-events');
    box.innerHTML = `
      <div class="flex items-center justify-between gap-3 mb-4">
        <div>
          <h3 class="text-xl font-bold text-gray-800">Rundown</h3>
          <p class="text-gray-600 text-sm">Kelola rundown lengkap. Operator memilih 1 acara aktif untuk ditampilkan di User App.</p>
        </div>
        <button id="e-add" class="bg-gradient-to-r from-blue-600 to-teal-500 text-white px-4 py-2 rounded-xl"><i class="fas fa-plus mr-2"></i>Tambah</button>
      </div>
    `;
    const tableWrap = document.createElement('div');
    box.appendChild(tableWrap);
    renderTable(tableWrap,
      [
        {key:'id',label:'ID'},
        {key:'day',label:'Hari'},
        {key:'time',label:'Waktu'},
        {key:'title',label:'Judul'}
      ],
      cache.events.map(x=>({ id:x.id, day:x.day, time:x.time, title:x.title })),
      (r)=>`<button class="e-set text-green-700" data-id="${htmlEsc(r.id)}" title="Set sebagai aktif"><i class="fas fa-bolt"></i></button>
            <button class="e-edit text-blue-700 ml-2" data-id="${htmlEsc(r.id)}"><i class="fas fa-pen"></i></button>
            <button class="e-del text-red-600 ml-2" data-id="${htmlEsc(r.id)}"><i class="fas fa-trash"></i></button>`
    );

    $('#e-add').onclick = async ()=>{
      const id = prompt('ID event? (mis: ev-001)');
      if(!id) return;
      const day = Number(prompt('Hari ke? (1-4)', '3')||'3');
      const time = prompt('Waktu (mis: 19:30 - 21:00)')||'';
      const title = prompt('Judul')||'';
      const description = prompt('Deskripsi')||'';
      const location = prompt('Lokasi')||'';
      const item = { id:String(id).trim(), day, time, title, description, location };
      await FGAPI.admin.eventsUpsert(token, item);
      utils.showNotification('Tersimpan','success');
      await loadEvents();
    };

    $$('.e-set', box).forEach(btn=>btn.onclick = async ()=>{
      await FGAPI.admin.setCurrentEvent(token, btn.dataset.id);
      utils.showNotification('Current event diubah','success');
      await renderControl();
    });

    $$('.e-edit', box).forEach(btn=>btn.onclick = async ()=>{
      const id = btn.dataset.id;
      const cur = cache.events.find(x=>x.id===id);
      if(!cur) return;
      const day = Number(prompt('Hari ke?', cur.day)||cur.day);
      const time = prompt('Waktu', cur.time)||cur.time;
      const title = prompt('Judul', cur.title)||cur.title;
      const description = prompt('Deskripsi', cur.description||'') ?? (cur.description||'');
      const location = prompt('Lokasi', cur.location||'') ?? (cur.location||'');
      await FGAPI.admin.eventsUpsert(token, { id, day, time, title, description, location });
      utils.showNotification('Tersimpan','success');
      await loadEvents();
    });

    $$('.e-del', box).forEach(btn=>btn.onclick = async ()=>{
      const id = btn.dataset.id;
      if(!confirm('Hapus event '+id+'?')) return;
      await FGAPI.admin.eventsDelete(token, id);
      utils.showNotification('Terhapus','info');
      await loadEvents();
    });
  }

  async function loadPrizes(){
    const data = await FGAPI.admin.prizesList(token);
    cache.prizes = data.items||[];
    const box = $('#tab-prizes');
    box.innerHTML = `
      <div class="flex items-center justify-between gap-3 mb-4">
        <div>
          <h3 class="text-xl font-bold text-gray-800">Doorprize</h3>
          <p class="text-gray-600 text-sm">Kelola jenis doorprize (nama, jumlah, gambar). Gambar bisa URL (Drive/Hosting) atau data URL base64.</p>
        </div>
        <button id="d-add" class="bg-gradient-to-r from-purple-600 to-pink-500 text-white px-4 py-2 rounded-xl"><i class="fas fa-plus mr-2"></i>Tambah</button>
      </div>
    `;
    const tableWrap = document.createElement('div');
    box.appendChild(tableWrap);
    renderTable(tableWrap,
      [
        {key:'id',label:'ID'},
        {key:'name',label:'Nama'},
        {key:'qty',label:'Jumlah'},
        {key:'image',label:'Gambar'}
      ],
      cache.prizes.map(x=>({ id:x.id, name:x.name, qty:x.qty, image:(x.image||'').slice(0,30) })),
      (r)=>`<button class="d-edit text-blue-700" data-id="${htmlEsc(r.id)}"><i class="fas fa-pen"></i></button>
            <button class="d-del text-red-600 ml-2" data-id="${htmlEsc(r.id)}"><i class="fas fa-trash"></i></button>`
    );

    $('#d-add').onclick = async ()=>{
      const id = prompt('ID doorprize? (mis: dp-01)');
      if(!id) return;
      const name = prompt('Nama doorprize?')||'';
      const qty = Number(prompt('Jumlah?','1')||'1');
      const image = prompt('URL Gambar (boleh kosong)')||'';
      await FGAPI.admin.prizesUpsert(token, { id:String(id).trim(), name, qty, image });
      utils.showNotification('Tersimpan','success');
      await loadPrizes();
    };

    $$('.d-edit', box).forEach(btn=>btn.onclick = async ()=>{
      const id = btn.dataset.id;
      const cur = cache.prizes.find(x=>x.id===id);
      if(!cur) return;
      const name = prompt('Nama?', cur.name)||cur.name;
      const qty = Number(prompt('Jumlah?', String(cur.qty))||String(cur.qty));
      const image = prompt('URL Gambar?', cur.image||'') ?? (cur.image||'');
      await FGAPI.admin.prizesUpsert(token, { id, name, qty, image });
      utils.showNotification('Tersimpan','success');
      await loadPrizes();
    });

    $$('.d-del', box).forEach(btn=>btn.onclick = async ()=>{
      const id = btn.dataset.id;
      if(!confirm('Hapus doorprize '+id+'?')) return;
      await FGAPI.admin.prizesDelete(token, id);
      utils.showNotification('Terhapus','info');
      await loadPrizes();
    });
  }

  async function loadUsers(){
    const data = await FGAPI.admin.usersList(token);
    cache.users = data.items||[];
    const box = $('#tab-users');
    box.innerHTML = `
      <div class="flex items-center justify-between gap-3 mb-4">
        <div>
          <h3 class="text-xl font-bold text-gray-800">User Panel</h3>
          <p class="text-gray-600 text-sm">Kelola akun login untuk Admin/Operator.</p>
        </div>
        <button id="u-add" class="bg-gradient-to-r from-blue-600 to-teal-500 text-white px-4 py-2 rounded-xl"><i class="fas fa-plus mr-2"></i>Tambah</button>
      </div>
    `;
    const tableWrap = document.createElement('div');
    box.appendChild(tableWrap);
    renderTable(tableWrap,
      [
        {key:'username',label:'Username'},
        {key:'name',label:'Nama'},
        {key:'role',label:'Role'},
        {key:'active',label:'Aktif'}
      ],
      cache.users.map(x=>({ username:x.username, name:x.name, role:x.role, active:x.active?'Y':'N' })),
      (r)=>`<button class="u-edit text-blue-700" data-u="${htmlEsc(r.username)}"><i class="fas fa-pen"></i></button>
            <button class="u-pass text-purple-700 ml-2" data-u="${htmlEsc(r.username)}" title="Reset password"><i class="fas fa-key"></i></button>`
    );

    $('#u-add').onclick = async ()=>{
      const username = prompt('Username?');
      if(!username) return;
      const name = prompt('Nama?')||username;
      const role = prompt('Role? (ADMIN/OPERATOR)', 'OPERATOR')||'OPERATOR';
      const password = prompt('Password awal?', 'user123')||'user123';
      await FGAPI.admin.usersUpsert(token, { username:String(username).trim(), name, role:String(role).toUpperCase(), active:true, password });
      utils.showNotification('Tersimpan','success');
      await loadUsers();
    };

    $$('.u-edit', box).forEach(btn=>btn.onclick = async ()=>{
      const username = btn.dataset.u;
      const cur = cache.users.find(x=>x.username===username);
      if(!cur) return;
      const name = prompt('Nama?', cur.name)||cur.name;
      const role = prompt('Role? (ADMIN/OPERATOR)', cur.role)||cur.role;
      const active = confirm('Aktifkan akun? (OK=aktif, Cancel=nonaktif)');
      await FGAPI.admin.usersUpsert(token, { username, name, role:String(role).toUpperCase(), active });
      utils.showNotification('Tersimpan','success');
      await loadUsers();
    });

    $$('.u-pass', box).forEach(btn=>btn.onclick = async ()=>{
      const username = btn.dataset.u;
      const np = prompt('Password baru untuk '+username+'?','user123');
      if(!np) return;
      await FGAPI.admin.usersResetPassword(token, username, np);
      utils.showNotification('Password direset','success');
    });
  }

  async function renderControl(){
    const box = $('#tab-control');
    let cur = null;
    try{ cur = await FGAPI.public.getCurrentEvent(); }catch{}
    const curTitle = cur?.event?.title || '-';
    const curId = cur?.event?.id || '';
    box.innerHTML = `
      <h3 class="text-xl font-bold text-gray-800 mb-2">Kontrol Cepat</h3>
      <div class="p-4 bg-gradient-to-r from-blue-50 to-teal-50 rounded-2xl">
        <div class="text-gray-700">Current Event:</div>
        <div class="text-lg font-bold text-gray-900">${htmlEsc(curTitle)}</div>
        <div class="text-sm text-gray-500">${htmlEsc(curId)}</div>
        <div class="mt-4 flex flex-wrap gap-3">
          <a href="doorprize.html" class="bg-gradient-to-r from-purple-600 to-pink-500 text-white px-4 py-2 rounded-xl"><i class="fas fa-gift mr-2"></i>Operator Doorprize</a>
          <a href="rundown.html" class="bg-gradient-to-r from-blue-600 to-teal-500 text-white px-4 py-2 rounded-xl"><i class="fas fa-calendar mr-2"></i>Operator Rundown</a>
        </div>
      </div>
    `;
  }

  // ------- Init -------
  document.addEventListener('DOMContentLoaded', async ()=>{
    bindTabs();
    $('#btn-login')?.addEventListener('click', doLogin);
    $('#password')?.addEventListener('keypress', (e)=>{ if(e.key==='Enter') doLogin(); });
    $('#btn-logout')?.addEventListener('click', doLogout);

    const ok = await ensureMe();
    if(ok && ok.role==='ADMIN'){
      showApp();
      await loadAll();
    }else{
      showLogin();
    }
  });
})();
