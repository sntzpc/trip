// ==========================
// FG2026 - Doorprize Feed (User)
// Menampilkan pemenang yang diundi oleh operator/admin
// ==========================

class DoorprizeFeed {
  constructor(){
    this.container = document.getElementById('doorprize-container');
    this.noWinner = document.getElementById('no-winner');
    this.load();
    this.startPolling();
  }

  async load(){
    if(!this.container) return;
    try{
      const data = await window.FGAPI.public.getDoorprizeFeed(10);
      const rows = (data && data.rows) ? data.rows : [];
      this.render(rows);
    }catch(e){
      console.warn('doorprize feed error:', e);
    }
  }

  startPolling(){
    setInterval(() => this.load(), 5000);
  }

  render(rows){
    if(!this.container) return;
    this.container.innerHTML = '';

    if(!rows || !rows.length){
      if(this.noWinner){
        this.noWinner.classList.remove('hidden');
        this.container.appendChild(this.noWinner);
      }
      return;
    }

    rows.forEach(r => {
      const el = document.createElement('div');
      el.className = 'p-4 border-2 border-yellow-200 bg-yellow-50 rounded-xl animate-fade-in';
      const status = String(r.status||'WIN');
      const badge = status === 'TAKEN'
        ? '<span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Diambil</span>'
        : (status === 'NO_SHOW'
            ? '<span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">Tidak Ambil</span>'
            : '<span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Menang</span>');

      const img = r.prize_image
        ? `<img src="${r.prize_image}" alt="${(r.prize_name||'Doorprize')}" class="w-14 h-14 object-cover rounded-lg border bg-white"/>`
        : `<div class="w-14 h-14 rounded-lg bg-purple-100 flex items-center justify-center"><i class="fas fa-gift text-purple-600 text-xl"></i></div>`;

      el.innerHTML = `
        <div class="flex items-start gap-4">
          ${img}
          <div class="flex-grow">
            <div class="flex items-center justify-between gap-2">
              <h4 class="font-bold text-gray-800">${r.name||'-'}</h4>
              ${badge}
            </div>
            <p class="text-gray-600 text-sm">NIK: ${r.nik||'-'}</p>
            <div class="mt-2 flex items-center">
              <div class="w-7 h-7 bg-gradient-to-r from-purple-500 to-pink-500 rounded flex items-center justify-center mr-2">
                <i class="fas fa-trophy text-white text-xs"></i>
              </div>
              <span class="font-semibold text-gray-800">${r.prize_name||'-'}</span>
            </div>
            <div class="mt-2 text-xs text-gray-500"><i class="far fa-clock mr-1"></i>${r.time_local||''}</div>
          </div>
        </div>
      `;
      this.container.appendChild(el);
    });
  }
}

const doorprize = new DoorprizeFeed();
