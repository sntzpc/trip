// Authentication Module
class Auth {
    constructor() {
        this.currentUser = null;
        this.attended = false;
        this.utils = window.utils || new Utils();
        this.initializeElements();
        this.loadAttendanceStatus();
    }

    initializeElements() {
        this.nikInput = document.getElementById('nik-input');
        this.checkNikBtn = document.getElementById('check-nik-btn');
        this.authError = document.getElementById('auth-error');
        this.authSuccess = document.getElementById('auth-success');
        this.alreadyAttended = document.getElementById('already-attended');
        this.familyList = document.getElementById('family-list');
        this.confirmAttendanceBtn = document.getElementById('confirm-attendance-btn');
        this.enterAppBtn = document.getElementById('enter-app-btn');
        this.authSection = document.getElementById('auth-section');
        this.appSection = document.getElementById('app-section');
        this.logoutBtn = document.getElementById('logout-btn');
        
        this.bindEvents();
    }

    bindEvents() {
        this.checkNikBtn.addEventListener('click', () => this.checkNIK());
        this.nikInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.checkNIK();
        });
        this.confirmAttendanceBtn.addEventListener('click', () => this.confirmAttendance());
        this.enterAppBtn.addEventListener('click', () => this.enterApp());
        this.logoutBtn.addEventListener('click', () => this.logout());
    }

    async checkNIK() {
        const nik = this.nikInput.value.trim();
        
        // Validasi NIK menggunakan utils
        const validation = this.utils.validateNIK(nik);
        if (!validation.valid) {
            this.showError('NIK tidak valid', validation.message);
            return;
        }
        
        // Cek apakah sudah absen (server)
        try {
            const st = await window.FGAPI.public.getAttendanceStatus(nik);
            if (st && st.already === true) {
                // Simpan user jika tersedia agar tombol "Masuk" tetap bisa tampil info user
                if (st.participant) this.currentUser = st.participant;
                this.showAlreadyAttended();
                return;
            }
        } catch (e) {
            this.showError('Gagal memeriksa status absensi', String(e.message || e));
            return;
        }
        
        // Cek apakah dalam radius lokasi
        const inLocation = await this.utils.checkLocation();
        if (!inLocation) {
            const locationName = window.AppConfig?.getEventLocation ? 
                window.AppConfig.getEventLocation().name : 'lokasi acara';
            this.showError('Tidak dapat melakukan absensi', `Anda berada di luar radius ${locationName}`);
            return;
        }
        
        // Cek apakah tanggal dan waktu acara
        if (!this.utils.isEventDate()) {
            this.showError('Tidak dapat melakukan absensi', 'Absensi hanya dapat dilakukan pada tanggal acara');
            return;
        }
        
        if (!this.utils.isGalaDinnerTime()) {
            const eventTime = window.AppConfig?.event?.galaDinnerDate ? 
                new Date(window.AppConfig.event.galaDinnerDate).toLocaleTimeString('id-ID', { 
                    hour: '2-digit', 
                    minute: '2-digit',
                    timeZone: 'Asia/Jakarta' 
                }) : '16:00';
            this.showError('Tidak dapat melakukan absensi', `Absensi hanya dapat dilakukan mulai pukul ${eventTime} WIB`);
            return;
        }
        
        // Ambil data peserta dari server
        try {
            const participant = await window.FGAPI.public.getParticipantByNIK(nik);
            if (!participant) {
                this.showError('NIK tidak ditemukan', 'Pastikan NIK yang dimasukkan sudah benar');
                return;
            }
            this.currentUser = participant;
            this.showSuccess(participant);
        } catch (e) {
            this.showError('Gagal memuat data peserta', String(e.message || e));
        }
    }

    showError(message, detail) {
        this.authError.classList.remove('hidden');
        document.getElementById('error-message').textContent = message;
        document.getElementById('error-detail').textContent = detail;
        this.authSuccess.classList.add('hidden');
        this.alreadyAttended.classList.add('hidden');
        
        // Auto hide error after configured time
        const timeout = window.AppConfig?.app?.notificationTimeout || 5000;
        setTimeout(() => {
            this.authError.classList.add('hidden');
        }, timeout);
    }

    showSuccess(participant) {
        this.authError.classList.add('hidden');
        this.authSuccess.classList.remove('hidden');
        this.alreadyAttended.classList.add('hidden');
        
        // Update UI dengan informasi acara dari konfigurasi
        const eventDate = window.AppConfig?.getEventDate ? 
            window.AppConfig.getEventDate() : new Date('2026-02-16T16:00:00+07:00');
        
        const dateString = eventDate.toLocaleDateString('id-ID', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        const locationName = window.AppConfig?.getEventLocation ? 
            window.AppConfig.getEventLocation().name : 'Novotel Pontianak';
        
        // Update teks informasi di form
        const eventInfoElements = document.querySelectorAll('.event-info');
        eventInfoElements.forEach(element => {
            if (element.id === 'event-date-info') {
                element.textContent = dateString;
            } else if (element.id === 'event-location-info') {
                element.textContent = locationName;
            }
        });
        
        // Tampilkan daftar keluarga
        this.renderFamilyList(participant.family);
    }

    showAlreadyAttended() {
        this.authError.classList.add('hidden');
        this.authSuccess.classList.add('hidden');
        this.alreadyAttended.classList.remove('hidden');
    }

    renderFamilyList(familyMembers) {
        this.familyList.innerHTML = '';
        
        familyMembers.forEach((member, index) => {
            const memberElement = document.createElement('div');
            memberElement.className = 'flex items-center p-4 bg-gray-50 rounded-xl';
            memberElement.innerHTML = `
                <input type="checkbox" id="member-${index}" class="checkbox-custom" checked>
                <label for="member-${index}" class="ml-3 flex-grow cursor-pointer">
                    <span class="font-medium text-gray-800">${member}</span>
                    ${index === 0 ? '<span class="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Peserta Utama</span>' : ''}
                </label>
            `;
            this.familyList.appendChild(memberElement);
        });
    }

    async confirmAttendance() {
        if (!this.currentUser) return;
        
        // Dapatkan anggota keluarga yang dicentang
        const checkboxes = document.querySelectorAll('#family-list input[type="checkbox"]');
        const attendedMembers = [];
        
        checkboxes.forEach((checkbox, index) => {
            if (checkbox.checked) {
                attendedMembers.push(this.currentUser.family[index]);
            }
        });
        
        if (attendedMembers.length === 0) {
            this.utils.showNotification('Pilih minimal satu anggota keluarga', 'warning');
            return;
        }
        
        // Simpan ke server
        try {
            await window.FGAPI.public.submitAttendance(this.currentUser.nik, attendedMembers);
            this.attended = true;
            this.utils.showNotification('Kehadiran berhasil dikonfirmasi', 'success');
            this.showAlreadyAttended();
        } catch (e) {
            this.utils.showNotification(String(e.message || e), 'error');
        }
    }

    // Status absensi sekarang dicek via server (lihat checkNIK)
    checkIfAlreadyAttended(nik) { return false; }

    enterApp() {
        if (!this.currentUser) return;
        
        // Simpan sesi user
        sessionStorage.setItem('currentUser', JSON.stringify(this.currentUser));
        
        // Tampilkan aplikasi utama
        this.authSection.classList.add('hidden');
        this.appSection.classList.remove('hidden');
        
        // Update user info di aplikasi utama
        this.updateUserInfo();
        
        // Update informasi acara di UI
        this.updateEventInfo();
        
        this.utils.showNotification(`Selamat datang, ${this.currentUser.name}`, 'success');
    }

    updateUserInfo() {
        const userNameElement = document.getElementById('user-name');
        const displayUserName = document.getElementById('display-user-name');
        const displayUserNik = document.getElementById('display-user-nik');
        const displayFamilyCount = document.getElementById('display-family-count');
        const authInfo = document.getElementById('auth-info');
        
        if (this.currentUser) {
            userNameElement.textContent = this.currentUser.name;
            displayUserName.textContent = this.currentUser.name;
            displayUserNik.textContent = this.currentUser.nik;
            displayFamilyCount.textContent = `${this.currentUser.family.length} orang`;
            authInfo.classList.remove('hidden');
        }
    }
    
    updateEventInfo() {
        // Update informasi acara di halaman utama
        const eventTitle = document.getElementById('main-event-title');
        const eventDate = document.getElementById('main-event-date');
        const eventLocation = document.getElementById('main-event-location');
        
        if (eventTitle && window.AppConfig?.event?.name) {
            eventTitle.textContent = window.AppConfig.event.name;
        }
        
        if (eventDate && window.AppConfig?.getEventDate) {
            const date = window.AppConfig.getEventDate();
            const dateString = date.toLocaleDateString('id-ID', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
            eventDate.textContent = dateString;
        }
        
        if (eventLocation && window.AppConfig?.getEventLocation) {
            const location = window.AppConfig.getEventLocation();
            eventLocation.textContent = `${location.name}, ${location.address}`;
        }
    }

    logout() {
        this.currentUser = null;
        this.attended = false;
        
        // Clear session
        sessionStorage.removeItem('currentUser');
        
        // Reset form
        this.nikInput.value = '';
        this.authError.classList.add('hidden');
        this.authSuccess.classList.add('hidden');
        this.alreadyAttended.classList.add('hidden');
        
        // Tampilkan form absensi
        this.appSection.classList.add('hidden');
        this.authSection.classList.remove('hidden');
        
        this.utils.showNotification('Anda telah keluar dari aplikasi', 'info');
    }

    loadAttendanceStatus() {
        // Cek apakah user sudah login dari session
        const savedUser = sessionStorage.getItem('currentUser');
        if (savedUser) {
            try {
                this.currentUser = JSON.parse(savedUser);
                this.authSection.classList.add('hidden');
                this.appSection.classList.remove('hidden');
                this.updateUserInfo();
                this.updateEventInfo();
            } catch (e) {
                console.error('Error loading user session:', e);
                sessionStorage.removeItem('currentUser');
            }
        }
    }
}

// Inisialisasi auth module
const auth = new Auth();