/* ==========================
   FG2026 - Doorprize Operator
   Role: OPERATOR / ADMIN
   ========================== */

(()=>{
  const $ = (s,r=document)=>r.querySelector(s);
  const KEY = 'fg_operator_token_v1';
  let token = localStorage.getItem(KEY)||'';
  let selectedPrize = '';

  function esc(s){
    return String(s??'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));
  }

  async function login(){
    const u = $('#username').value.trim();
    const p = $('#password').value;
    try{
      const r = await FGAPI.auth.login(u,p);
      token = r.token;
      localStorage.setItem(KEY, token);
      $('#login').classList.add('hidden');
      $('#app').classList.remove('hidden');
      $('#btn-logout').classList.remove('hidden');
      await loadPrizes();
      await refreshWinners();
      utils.showNotification('Login berhasil', 'success');
    }catch(e){
      utils.showNotification(String(e.message||e), 'error');
    }
  }

  async function ensureLogged(){
    if(!token) return false;
    try{ await FGAPI.auth.me(token); return true; }catch{ return false; }
  }

  async function loadPrizes(){
    const r = await FGAPI.admin.prizesList(token);
    const sel = $('#prize');
    sel.innerHTML = '<option value="">Pilih doorprize...</option>';
    (r.rows||[]).forEach(it=>{
      const opt = document.createElement('option');
      opt.value = it.id;
      opt.textContent = `${it.name} (sisa: ${it.qty_remaining})`;
      sel.appendChild(opt);
    });
    if(!selectedPrize && r.rows && r.rows.length){
      selectedPrize = r.rows[0].id;
      sel.value = selectedPrize;
    }
  }

  async function refreshWinners(){
    if(!selectedPrize){
      $('#winner-list').innerHTML = '<div class="text-gray-500">Pilih doorprize dulu.</div>';
      return;
    }
    const r = await FGAPI.admin.doorprizeListByPrize(token, selectedPrize);
    const box = $('#winner-list');
    box.innerHTML = '';
    const rows = r.rows||[];
    if(!rows.length){
      box.innerHTML = '<div class="text-gray-500">Belum ada pemenang.</div>';
      return;
    }
    rows.forEach(w=>{
      const el = document.createElement('div');
      el.className = 'p-4 border rounded-xl bg-gray-50';
      const badge = w.status==='TAKEN'
        ? '<span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">Diambil</span>'
        : (w.status==='NO_SHOW'
            ? '<span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full">Tidak Ambil</span>'
            : '<span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Menang</span>');

      el.innerHTML = `
        <div class="flex items-start justify-between gap-3">
          <div>
            <div class="font-bold text-gray-800">${esc(w.name)}</div>
            <div class="text-sm text-gray-600">NIK: ${esc(w.nik)} | Slot: ${esc(w.slot)}</div>
            <div class="text-xs text-gray-500 mt-1">${esc(w.time_local||'')}</div>
          </div>
          <div class="flex items-center gap-2">
            ${badge}
          </div>
        </div>
        <div class="mt-3 flex gap-2">
          <button class="btn-taken px-3 py-2 rounded-lg bg-green-600 text-white text-sm" data-id="${esc(w.draw_id)}"><i class="fas fa-check mr-1"></i>Diambil</button>
          <button class="btn-reroll px-3 py-2 rounded-lg bg-red-600 text-white text-sm" data-id="${esc(w.draw_id)}"><i class="fas fa-trash mr-1"></i>Hapus & Acak</button>
        </div>
      `;
      box.appendChild(el);
    });

    box.querySelectorAll('.btn-taken').forEach(b=>b.addEventListener('click', async ()=>{
      try{ await FGAPI.admin.doorprizeMarkTaken(token, b.dataset.id); await refreshWinners(); utils.showNotification('OK', 'success'); }catch(e){ utils.showNotification(String(e.message||e),'error'); }
    }));
    box.querySelectorAll('.btn-reroll').forEach(b=>b.addEventListener('click', async ()=>{
      if(!confirm('Hapus pemenang ini dan acak pengganti?')) return;
      try{ await FGAPI.admin.doorprizeRemoveAndRedraw(token, b.dataset.id); await loadPrizes(); await refreshWinners(); utils.showNotification('Diacak ulang', 'success'); }catch(e){ utils.showNotification(String(e.message||e),'error'); }
    }));
  }

  async function draw(){
    if(!selectedPrize){ utils.showNotification('Pilih doorprize dulu', 'warning'); return; }
    const n = Math.max(1, parseInt($('#count').value||'1',10));
    try{
      await FGAPI.admin.drawDoorprize(token, selectedPrize, n);
      await loadPrizes();
      await refreshWinners();
      utils.showNotification('Undian selesai', 'success');
    }catch(e){
      utils.showNotification(String(e.message||e), 'error');
    }
  }

  function logout(){
    token='';
    localStorage.removeItem(KEY);
    location.reload();
  }

  // boot
  document.addEventListener('DOMContentLoaded', async ()=>{
    $('#btn-login').addEventListener('click', login);
    $('#btn-logout').addEventListener('click', logout);
    $('#prize').addEventListener('change', async (e)=>{ selectedPrize = e.target.value; await refreshWinners(); });
    $('#btn-draw').addEventListener('click', draw);
    $('#btn-refresh').addEventListener('click', async ()=>{ await loadPrizes(); await refreshWinners(); });

    if(await ensureLogged()){
      $('#login').classList.add('hidden');
      $('#app').classList.remove('hidden');
      $('#btn-logout').classList.remove('hidden');
      await loadPrizes();
      await refreshWinners();
    }
  });
})();
