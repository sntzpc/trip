// Global Variables
let currentUser = null;
let userSession = null;
let map = null;
let vehicleMarkers = {};
let html5QrCode = null;
let appData = {
    participants: [],
    vehicles: [],
    arrivals: [],
    regions: [],
    estates: []
};

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
    // Hide loading screen after 2 seconds
    setTimeout(() => {
        document.getElementById('loadingScreen').style.opacity = '0';
        setTimeout(() => {
            document.getElementById('loadingScreen').style.display = 'none';
        }, 500);
    }, 2000);
    
    // Initialize date time display
    updateDateTime();
    setInterval(updateDateTime, 1000);
    
    // Initialize countdown
    updateCountdown();
    setInterval(updateCountdown, 60000);
    
    // Check for existing session
    checkExistingSession();
    
    // Initialize event listeners
    initializeEventListeners();
    
    // Initialize map (will be shown when needed)
    initializeMap();
});

// Initialize Event Listeners
function initializeEventListeners() {
    // Login form
    document.getElementById('password').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') login();
    });
    
    // Prevent double clicks
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            const btn = this;
            if (btn.classList.contains('processing')) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
        });
    });
}

// Check for existing session
function checkExistingSession() {
    const sessionData = localStorage.getItem('kmp1_fg_session');
    if (sessionData) {
        const session = JSON.parse(sessionData);
        const now = new Date().getTime();
        
        // Check if session is still valid (3 days)
        if (session.expiry > now) {
            userSession = session;
            // Auto-login with session
            simulateLogin(session.userId);
        } else {
            // Session expired, clear it
            localStorage.removeItem('kmp1_fg_session');
        }
    }
}

// Update Date Time Display
function updateDateTime() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    document.getElementById('currentDateTime').textContent = 
        now.toLocaleDateString('id-ID', options);
}

// Update Countdown
function updateCountdown() {
    const eventDate = new Date('2026-02-14');
    const now = new Date();
    const diff = eventDate - now;
    
    if (diff > 0) {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        
        document.getElementById('countdownTimer').textContent = 
            `${days} Hari ${hours} Jam ${minutes} Menit`;
    } else {
        document.getElementById('countdownTimer').textContent = 'Sedang Berlangsung';
    }
}

// Login Function
function login() {
    const nik = document.getElementById('nik').value.trim();
    const password = document.getElementById('password').value;
    
    if (!nik) {
        showNotification('Masukkan NIK Anda', 'error');
        return;
    }
    
    if (!password) {
        showNotification('Masukkan password Anda', 'error');
        return;
    }
    
    // Show spinner
    const loginBtn = document.getElementById('loginBtn');
    const btnText = loginBtn.querySelector('.btn-text');
    const btnSpinner = loginBtn.querySelector('.btn-spinner');
    
    btnText.style.display = 'none';
    btnSpinner.style.display = 'block';
    loginBtn.classList.add('processing');
    loginBtn.disabled = true;
    
    // Simulate API call (in real app, this would be a GAS call)
    setTimeout(() => {
        // This is a simulation - in production, you would call GAS backend
        simulateLogin(nik);
        
        // Hide spinner
        btnText.style.display = 'block';
        btnSpinner.style.display = 'none';
        loginBtn.classList.remove('processing');
        loginBtn.disabled = false;
    }, 1500);
}

// Simulate Login (Replace with actual GAS API call)
function simulateLogin(nik) {
    // In production, this would call your GAS backend
    // For now, we'll use mock data
    
    // Check if user is admin (NIK starting with 'ADM')
    const isAdmin = nik.startsWith('ADM');
    
    // Mock user data
    currentUser = {
        nik: nik,
        name: nik === 'ADM001' ? 'ADMINISTRATOR' : `KARYAWAN ${nik}`,
        role: isAdmin ? 'admin' : 'user',
        region: 'REGION 1',
        estate: 'ESTATE A',
        family: [
            { name: 'ISTRI KARYAWAN', relationship: 'istri', nik: `${nik}S` },
            { name: 'ANAK PERTAMA', relationship: 'anak', nik: `${nik}C1` },
            { name: 'ANAK KEDUA', relationship: 'anak', nik: `${nik}C2` }
        ]
    };
    
    // Create session (3 days from now)
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + 3);
    
    userSession = {
        userId: nik,
        expiry: expiry.getTime(),
        role: isAdmin ? 'admin' : 'user'
    };
    
    // Save session to localStorage
    localStorage.setItem('kmp1_fg_session', JSON.stringify(userSession));
    
    // Update UI
    document.getElementById('userName').textContent = currentUser.name.toUpperCase();
    document.getElementById('currentUserInfo').textContent = 
        `${currentUser.name} - ${currentUser.nik} (${currentUser.estate})`;
    
    // Show/hide admin menu
    if (isAdmin) {
        document.getElementById('adminMenu').style.display = 'flex';
    }
    
    // Load initial data
    loadInitialData();
    
    // Switch to main app
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('mainApp').style.display = 'block';
    
    // Show dashboard by default
    showDashboard();
    
    showNotification('Login berhasil!', 'success');
}

// Load Initial Data
function loadInitialData() {
    // Show loading indicator
    showLoading();
    
    // Simulate API call (replace with actual GAS call)
    setTimeout(() => {
        // Mock data
        appData.participants = generateMockParticipants();
        appData.vehicles = generateMockVehicles();
        appData.arrivals = generateMockArrivals();
        appData.regions = ['REGION 1', 'REGION 2', 'REGION 3'];
        appData.estates = ['ESTATE A', 'ESTATE B', 'ESTATE C', 'ESTATE D'];
        
        // Update dashboard
        updateDashboard();
        
        // Update arrival status
        updateArrivalStatus();
        
        // Hide loading
        hideLoading();
    }, 1000);
}

// Generate Mock Participants
function generateMockParticipants() {
    const participants = [];
    
    // Add current user and family
    participants.push({
        nik: currentUser.nik,
        name: currentUser.name,
        relationship: 'staff',
        region: currentUser.region,
        estate: currentUser.estate,
        vehicle: null,
        arrived: false,
        arrivalTime: null
    });
    
    currentUser.family.forEach(member => {
        participants.push({
            nik: member.nik,
            name: member.name,
            relationship: member.relationship,
            region: currentUser.region,
            estate: currentUser.estate,
            vehicle: null,
            arrived: false,
            arrivalTime: null
        });
    });
    
    // Add more mock participants
    for (let i = 1; i <= 50; i++) {
        const regionNum = Math.floor(Math.random() * 3) + 1;
        const estateNum = Math.floor(Math.random() * 4) + 1;
        const estateChar = String.fromCharCode(64 + estateNum);
        
        participants.push({
            nik: `KMP${String(i).padStart(3, '0')}`,
            name: `KARYAWAN ${i}`,
            relationship: 'staff',
            region: `REGION ${regionNum}`,
            estate: `ESTATE ${estateChar}`,
            vehicle: null,
            arrived: Math.random() > 0.7,
            arrivalTime: Math.random() > 0.7 ? new Date() : null
        });
        
        // Add family members for some participants
        if (i % 3 === 0) {
            participants.push({
                nik: `KMP${String(i).padStart(3, '0')}S`,
                name: `ISTRI KARYAWAN ${i}`,
                relationship: 'istri',
                region: `REGION ${regionNum}`,
                estate: `ESTATE ${estateChar}`,
                vehicle: null,
                arrived: Math.random() > 0.7,
                arrivalTime: Math.random() > 0.7 ? new Date() : null
            });
        }
        
        if (i % 4 === 0) {
            participants.push({
                nik: `KMP${String(i).padStart(3, '0')}C`,
                name: `ANAK KARYAWAN ${i}`,
                relationship: 'anak',
                region: `REGION ${regionNum}`,
                estate: `ESTATE ${estateChar}`,
                vehicle: null,
                arrived: Math.random() > 0.7,
                arrivalTime: Math.random() > 0.7 ? new Date() : null
            });
        }
    }
    
    return participants;
}

// Generate Mock Vehicles
function generateMockVehicles() {
    const vehicles = [];
    const types = ['Dinas', 'Pribadi', 'Sewa'];
    
    for (let i = 1; i <= 15; i++) {
        const type = types[Math.floor(Math.random() * types.length)];
        const capacity = type === 'Sewa' ? Math.floor(Math.random() * 10) + 10 : 5;
        
        vehicles.push({
            code: `KMP1-V${String(i).padStart(2, '0')}`,
            type: type,
            capacity: capacity,
            driver: `Pengemudi ${i}`,
            currentLocation: {
                lat: -0.022 + (Math.random() * 0.1 - 0.05),
                lng: 109.342 + (Math.random() * 0.1 - 0.05)
            },
            status: Math.random() > 0.7 ? 'arrived' : Math.random() > 0.5 ? 'on_the_way' : 'waiting',
            passengers: [],
            barcode: `VHC${String(i).padStart(3, '0')}`
        });
    }
    
    return vehicles;
}

// Generate Mock Arrivals
function generateMockArrivals() {
    const arrivals = [];
    const now = new Date();
    
    for (let i = 1; i <= 30; i++) {
        const arrivalTime = new Date(now.getTime() - Math.random() * 3600000);
        
        arrivals.push({
            nik: `KMP${String(i).padStart(3, '0')}`,
            arrivalTime: arrivalTime,
            confirmedBy: 'system'
        });
    }
    
    return arrivals;
}

// Update Dashboard
function updateDashboard() {
    // Calculate totals
    const totalParticipants = appData.participants.length;
    const totalVehicles = appData.vehicles.length;
    const totalArrived = appData.participants.filter(p => p.arrived).length;
    const totalOnRoad = appData.vehicles.filter(v => v.status === 'on_the_way').length;
    
    // Update display
    document.getElementById('totalParticipants').textContent = totalParticipants;
    document.getElementById('totalVehicles').textContent = totalVehicles;
    document.getElementById('totalArrived').textContent = totalArrived;
    document.getElementById('totalOnRoad').textContent = totalOnRoad;
    
    // Update arrival breakdown
    const staffArrived = appData.participants.filter(p => p.relationship === 'staff' && p.arrived).length;
    const wifeArrived = appData.participants.filter(p => p.relationship === 'istri' && p.arrived).length;
    const childArrived = appData.participants.filter(p => p.relationship === 'anak' && p.arrived).length;
    
    document.getElementById('staffArrived').textContent = staffArrived;
    document.getElementById('wifeArrived').textContent = wifeArrived;
    document.getElementById('childArrived').textContent = childArrived;
    
    // Update arrived table
    updateArrivedTable();
    
    // Update region cards
    updateRegionCards();
    
    // Update vehicle list
    updateVehicleList();
}

// Update Arrived Table
function updateArrivedTable() {
    const tableBody = document.querySelector('#arrivedTable tbody');
    tableBody.innerHTML = '';
    
    const arrivedParticipants = appData.participants
        .filter(p => p.arrived)
        .slice(0, 10); // Show only first 10
    
    arrivedParticipants.forEach(participant => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${participant.name}</td>
            <td>${participant.nik}</td>
            <td>${participant.vehicle || '-'}</td>
            <td>${participant.arrivalTime ? formatTime(participant.arrivalTime) : '-'}</td>
            <td><span class="status-badge badge-arrived">Tiba</span></td>
        `;
        
        tableBody.appendChild(row);
    });
}

// Update Region Cards
function updateRegionCards() {
    const regionCards = document.getElementById('regionCards');
    regionCards.innerHTML = '';
    
    // Group participants by region
    const regionGroups = {};
    appData.participants.forEach(p => {
        if (!regionGroups[p.region]) {
            regionGroups[p.region] = { total: 0, arrived: 0 };
        }
        regionGroups[p.region].total++;
        if (p.arrived) regionGroups[p.region].arrived++;
    });
    
    // Create cards for each region
    Object.keys(regionGroups).forEach(region => {
        const card = document.createElement('div');
        card.className = 'region-card';
        card.onclick = () => showEstateDetails(region);
        
        card.innerHTML = `
            <h4>${region}</h4>
            <p>${regionGroups[region].arrived}/${regionGroups[region].total}</p>
            <small>Peserta</small>
        `;
        
        regionCards.appendChild(card);
    });
}

// Update Vehicle List
function updateVehicleList() {
    const vehicleList = document.getElementById('vehicleList');
    vehicleList.innerHTML = '';
    
    appData.vehicles.forEach(vehicle => {
        const card = document.createElement('div');
        card.className = 'vehicle-card';
        
        let statusText = '';
        let statusClass = '';
        
        switch(vehicle.status) {
            case 'arrived':
                statusText = 'Telah Tiba';
                statusClass = 'status-arrived';
                break;
            case 'on_the_way':
                statusText = 'Dalam Perjalanan';
                statusClass = 'status-ontheway';
                break;
            default:
                statusText = 'Menunggu';
                statusClass = 'status-waiting';
        }
        
        card.innerHTML = `
            <h4>${vehicle.code}</h4>
            <p><strong>Jenis:</strong> ${vehicle.type}</p>
            <p><strong>Pengemudi:</strong> ${vehicle.driver}</p>
            <p><strong>Penumpang:</strong> ${vehicle.passengers.length}/${vehicle.capacity}</p>
            <span class="vehicle-status ${statusClass}">${statusText}</span>
        `;
        
        card.onclick = () => showVehiclePassengers(vehicle.code);
        vehicleList.appendChild(card);
    });
}

// Navigation Functions
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');
}

function showDashboard() {
    switchPage('dashboardPage');
    updateDashboard();
}

function showScan() {
    switchPage('scanPage');
}

function showMap() {
    switchPage('mapPage');
    setTimeout(() => {
        if (map) map.invalidateSize();
        updateMap();
    }, 100);
}

function showArrival() {
    switchPage('arrivalPage');
    updateArrivalStatus();
}

function showParticipants() {
    switchPage('participantsPage');
    updateParticipantsTable();
}

function showAdmin() {
    if (currentUser.role !== 'admin') {
        showNotification('Akses ditolak. Hanya admin yang dapat mengakses panel ini.', 'error');
        return;
    }
    switchPage('adminPage');
    loadAdminData();
}

function switchPage(pageId) {
    // Hide all pages
    const pages = document.querySelectorAll('.content-page');
    pages.forEach(page => {
        page.style.display = 'none';
    });
    
    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(item => {
        item.classList.remove('active');
    });
    
    // Show selected page
    document.getElementById(pageId).style.display = 'block';
    
    // Update active menu item
    let menuItemSelector = '';
    switch(pageId) {
        case 'dashboardPage':
            menuItemSelector = '.menu-item:nth-child(1)';
            break;
        case 'scanPage':
            menuItemSelector = '.menu-item:nth-child(2)';
            break;
        case 'mapPage':
            menuItemSelector = '.menu-item:nth-child(3)';
            break;
        case 'arrivalPage':
            menuItemSelector = '.menu-item:nth-child(4)';
            break;
        case 'participantsPage':
            menuItemSelector = '.menu-item:nth-child(5)';
            break;
    }
    
    const activeMenuItem = document.querySelector(menuItemSelector);
    if (activeMenuItem) {
        activeMenuItem.classList.add('active');
    }
}

// Initialize Map
function initializeMap() {
    // Center on Pontianak
    map = L.map('map').setView([-0.022, 109.342], 13);
    
    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
}

// Update Map with Vehicles
function updateMap() {
    // Clear existing markers
    Object.values(vehicleMarkers).forEach(marker => {
        if (marker) map.removeLayer(marker);
    });
    vehicleMarkers = {};
    
    // Add markers for each vehicle
    appData.vehicles.forEach(vehicle => {
        let markerColor;
        switch(vehicle.status) {
            case 'arrived': markerColor = '#2ecc71'; break;
            case 'on_the_way': markerColor = '#e74c3c'; break;
            default: markerColor = '#3498db';
        }
        
        const marker = L.circleMarker([vehicle.currentLocation.lat, vehicle.currentLocation.lng], {
            color: markerColor,
            fillColor: markerColor,
            fillOpacity: 0.7,
            radius: 10
        }).addTo(map);
        
        marker.bindPopup(`
            <strong>${vehicle.code}</strong><br>
            Jenis: ${vehicle.type}<br>
            Pengemudi: ${vehicle.driver}<br>
            Status: ${vehicle.status === 'arrived' ? 'Telah Tiba' : 
                     vehicle.status === 'on_the_way' ? 'Dalam Perjalanan' : 'Menunggu'}<br>
            Penumpang: ${vehicle.passengers.length}/${vehicle.capacity}
        `);
        
        vehicleMarkers[vehicle.code] = marker;
    });
}

// Update Arrival Status
function updateArrivalStatus() {
    const userStatus = document.getElementById('userArrivalStatus');
    const userParticipant = appData.participants.find(p => p.nik === currentUser.nik);
    
    if (userParticipant && userParticipant.arrived) {
        userStatus.innerHTML = `
            <div class="status-icon arrived">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="status-details">
                <h4>Telah Tiba</h4>
                <p>Anda tiba pada ${formatTime(userParticipant.arrivalTime)}</p>
            </div>
        `;
        document.getElementById('confirmArrivalBtn').style.display = 'none';
    } else {
        userStatus.innerHTML = `
            <div class="status-icon not-arrived">
                <i class="fas fa-clock"></i>
            </div>
            <div class="status-details">
                <h4>Belum Tiba</h4>
                <p>Anda belum mengkonfirmasi kedatangan</p>
            </div>
        `;
        document.getElementById('confirmArrivalBtn').style.display = 'block';
    }
    
    // Update family list
    updateFamilyList();
}

// Update Family List
function updateFamilyList() {
    const familyList = document.getElementById('familyList');
    familyList.innerHTML = '';
    
    currentUser.family.forEach(member => {
        const memberParticipant = appData.participants.find(p => p.nik === member.nik);
        const isArrived = memberParticipant && memberParticipant.arrived;
        
        const memberDiv = document.createElement('div');
        memberDiv.className = `family-member ${isArrived ? 'arrived' : ''}`;
        
        memberDiv.innerHTML = `
            <div>
                <h4>${member.name}</h4>
                <p>${member.relationship.toUpperCase()} - ${member.nik}</p>
            </div>
            <div>
                ${isArrived ? 
                    `<span class="status-badge badge-arrived">Tiba ${formatTime(memberParticipant.arrivalTime)}</span>` :
                    `<button class="btn-secondary" onclick="confirmFamilyArrival('${member.nik}')">Konfirmasi</button>`
                }
            </div>
        `;
        
        familyList.appendChild(memberDiv);
    });
}

// Confirm Arrival
function confirmArrival() {
    const btn = document.getElementById('confirmArrivalBtn');
    const btnText = btn.querySelector('.btn-text');
    const btnSpinner = btn.querySelector('.btn-spinner');
    
    btnText.style.display = 'none';
    btnSpinner.style.display = 'block';
    btn.classList.add('processing');
    btn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // Update local data
        const userIndex = appData.participants.findIndex(p => p.nik === currentUser.nik);
        if (userIndex !== -1) {
            appData.participants[userIndex].arrived = true;
            appData.participants[userIndex].arrivalTime = new Date();
            
            // Add to arrivals list
            appData.arrivals.push({
                nik: currentUser.nik,
                arrivalTime: new Date(),
                confirmedBy: 'self'
            });
        }
        
        // Update UI
        updateArrivalStatus();
        updateDashboard();
        
        // Reset button
        btnText.style.display = 'block';
        btnSpinner.style.display = 'none';
        btn.classList.remove('processing');
        btn.disabled = false;
        
        showNotification('Kedatangan Anda berhasil dikonfirmasi!', 'success');
    }, 1500);
}

// Confirm Family Arrival
function confirmFamilyArrival(familyNik) {
    // Find family member
    const memberIndex = appData.participants.findIndex(p => p.nik === familyNik);
    if (memberIndex !== -1) {
        appData.participants[memberIndex].arrived = true;
        appData.participants[memberIndex].arrivalTime = new Date();
        
        // Add to arrivals list
        appData.arrivals.push({
            nik: familyNik,
            arrivalTime: new Date(),
            confirmedBy: currentUser.nik
        });
        
        // Update UI
        updateFamilyList();
        updateDashboard();
        
        showNotification('Kedatangan keluarga berhasil dikonfirmasi!', 'success');
    }
}

// Start Scanning
function startScanning() {
    const scanBtn = document.getElementById('startScanBtn');
    const btnText = scanBtn.querySelector('.btn-text');
    const btnSpinner = scanBtn.querySelector('.btn-spinner');
    
    btnText.style.display = 'none';
    btnSpinner.style.display = 'block';
    scanBtn.classList.add('processing');
    scanBtn.disabled = true;
    
    // Initialize scanner
    html5QrCode = new Html5Qrcode("scannerBox");
    
    const config = { fps: 10, qrbox: 250 };
    
    html5QrCode.start(
        { facingMode: "environment" },
        config,
        onScanSuccess,
        onScanFailure
    ).then(() => {
        // Scanning started
        btnText.textContent = 'Berhenti Scan';
        btnText.style.display = 'block';
        btnSpinner.style.display = 'none';
        scanBtn.classList.remove('processing');
        scanBtn.disabled = false;
        scanBtn.onclick = stopScanning;
    }).catch(err => {
        console.error("Scanner error:", err);
        btnText.textContent = 'Mulai Scan';
        btnText.style.display = 'block';
        btnSpinner.style.display = 'none';
        scanBtn.classList.remove('processing');
        scanBtn.disabled = false;
        showNotification('Gagal mengakses kamera. Pastikan izin kamera diberikan.', 'error');
    });
}

// Stop Scanning
function stopScanning() {
    if (html5QrCode) {
        html5QrCode.stop().then(() => {
            html5QrCode.clear();
            html5QrCode = null;
            
            const scanBtn = document.getElementById('startScanBtn');
            scanBtn.querySelector('.btn-text').textContent = 'Mulai Scan';
            scanBtn.onclick = startScanning;
        }).catch(err => {
            console.error("Failed to stop scanner:", err);
        });
    }
}

// On Scan Success
function onScanSuccess(decodedText) {
    // Stop scanner
    stopScanning();
    
    // Process scanned vehicle code
    processVehicleCode(decodedText);
}

// On Scan Failure
function onScanFailure(error) {
    // Usually, we just ignore scan failures
    console.warn(`QR scan failed: ${error}`);
}

// Process Vehicle Code
function processVehicleCode(vehicleCode) {
    // Find vehicle
    const vehicle = appData.vehicles.find(v => v.code === vehicleCode || v.barcode === vehicleCode);
    
    if (!vehicle) {
        showNotification('Kendaraan tidak ditemukan. Periksa kode barcode.', 'error');
        return;
    }
    
    // Check capacity
    if (vehicle.passengers.length >= vehicle.capacity) {
        showNotification(`Kendaraan ${vehicle.code} sudah penuh. Kapasitas: ${vehicle.capacity}`, 'warning');
        return;
    }
    
    // Show result
    const resultDetails = document.getElementById('resultDetails');
    resultDetails.innerHTML = `
        <p><strong>Kendaraan:</strong> ${vehicle.code}</p>
        <p><strong>Jenis:</strong> ${vehicle.type}</p>
        <p><strong>Pengemudi:</strong> ${vehicle.driver}</p>
        <p><strong>Kapasitas:</strong> ${vehicle.passengers.length}/${vehicle.capacity}</p>
        <p><strong>Status:</strong> ${vehicle.status === 'arrived' ? 'Telah Tiba' : 
                                      vehicle.status === 'on_the_way' ? 'Dalam Perjalanan' : 'Menunggu'}</p>
        <hr>
        <p>Anda dan keluarga akan ditempatkan di kendaraan ini.</p>
    `;
    
    document.getElementById('scanResult').style.display = 'block';
    
    // Store current vehicle assignment
    window.currentVehicleAssignment = vehicle.code;
}

// Manual Vehicle Submit
function manualVehicleSubmit() {
    const vehicleCode = document.getElementById('vehicleCodeInput').value.trim();
    
    if (!vehicleCode) {
        showNotification('Masukkan kode kendaraan', 'error');
        return;
    }
    
    const btn = document.getElementById('manualSubmitBtn');
    const btnText = btn.querySelector('.btn-text');
    const btnSpinner = btn.querySelector('.btn-spinner');
    
    btnText.style.display = 'none';
    btnSpinner.style.display = 'block';
    btn.classList.add('processing');
    btn.disabled = true;
    
    // Simulate processing
    setTimeout(() => {
        processVehicleCode(vehicleCode);
        
        btnText.style.display = 'block';
        btnSpinner.style.display = 'none';
        btn.classList.remove('processing');
        btn.disabled = false;
    }, 1000);
}

// Confirm Assignment
function confirmAssignment() {
    const vehicleCode = window.currentVehicleAssignment;
    if (!vehicleCode) return;
    
    const btn = document.querySelector('#scanResult .btn-primary');
    const btnText = btn.querySelector('.btn-text');
    const btnSpinner = btn.querySelector('.btn-spinner');
    
    btnText.style.display = 'none';
    btnSpinner.style.display = 'block';
    btn.classList.add('processing');
    btn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // Update vehicle passengers
        const vehicleIndex = appData.vehicles.findIndex(v => v.code === vehicleCode);
        if (vehicleIndex !== -1) {
            // Add current user
            if (!appData.vehicles[vehicleIndex].passengers.includes(currentUser.nik)) {
                appData.vehicles[vehicleIndex].passengers.push(currentUser.nik);
            }
            
            // Update user's vehicle assignment
            const userIndex = appData.participants.findIndex(p => p.nik === currentUser.nik);
            if (userIndex !== -1) {
                appData.participants[userIndex].vehicle = vehicleCode;
            }
            
            // Add family members
            currentUser.family.forEach(member => {
                if (!appData.vehicles[vehicleIndex].passengers.includes(member.nik)) {
                    appData.vehicles[vehicleIndex].passengers.push(member.nik);
                }
                
                const memberIndex = appData.participants.findIndex(p => p.nik === member.nik);
                if (memberIndex !== -1) {
                    appData.participants[memberIndex].vehicle = vehicleCode;
                }
            });
        }
        
        // Reset UI
        document.getElementById('scanResult').style.display = 'none';
        document.getElementById('vehicleCodeInput').value = '';
        
        // Reset button
        btnText.style.display = 'block';
        btnSpinner.style.display = 'none';
        btn.classList.remove('processing');
        btn.disabled = false;
        
        showNotification(`Anda dan keluarga berhasil ditempatkan di ${vehicleCode}`, 'success');
        delete window.currentVehicleAssignment;
    }, 1500);
}

// Update Participants Table
function updateParticipantsTable() {
    const tableBody = document.querySelector('#participantsTable tbody');
    tableBody.innerHTML = '';
    
    appData.participants.forEach(participant => {
        const row = document.createElement('tr');
        
        let relationshipText = '';
        switch(participant.relationship) {
            case 'staff': relationshipText = 'Staff'; break;
            case 'istri': relationshipText = 'Istri'; break;
            case 'anak': relationshipText = 'Anak'; break;
        }
        
        row.innerHTML = `
            <td>${participant.name}</td>
            <td>${participant.nik}</td>
            <td>${relationshipText}</td>
            <td>${participant.vehicle || '-'}</td>
            <td>
                ${participant.arrived ? 
                    '<span class="status-badge badge-arrived">Tiba</span>' : 
                    '<span class="status-badge badge-not-arrived">Belum</span>'
                }
            </td>
            <td>${participant.arrivalTime ? formatTime(participant.arrivalTime) : '-'}</td>
        `;
        
        tableBody.appendChild(row);
    });
}

// Search Participants
function searchParticipants() {
    const searchTerm = document.getElementById('participantSearch').value.toLowerCase();
    const filterStatus = document.getElementById('participantFilter').value;
    
    const rows = document.querySelectorAll('#participantsTable tbody tr');
    
    rows.forEach(row => {
        const name = row.cells[0].textContent.toLowerCase();
        const nik = row.cells[1].textContent.toLowerCase();
        const status = row.cells[4].querySelector('.status-badge').textContent;
        
        const matchesSearch = name.includes(searchTerm) || nik.includes(searchTerm);
        const matchesFilter = filterStatus === 'all' || 
            (filterStatus === 'arrived' && status === 'Tiba') ||
            (filterStatus === 'not_arrived' && status === 'Belum');
        
        row.style.display = matchesSearch && matchesFilter ? '' : 'none';
    });
}

// Filter Participants
function filterParticipants() {
    searchParticipants(); // Reuse search function
}

// Filter Map Vehicles
function filterMapVehicles() {
    const filterValue = document.getElementById('vehicleFilter').value;
    
    // Update map based on filter
    // Implementation depends on your specific filtering requirements
}

// Show Region Details
function showRegionDetails() {
    document.querySelector('.stats-cards').style.display = 'none';
    document.getElementById('regionDetails').style.display = 'block';
    document.getElementById('arrivalDetails').style.display = 'none';
}

// Show Estate Details
function showEstateDetails(region) {
    // Implement estate details view
    alert(`Detail untuk ${region} akan ditampilkan di sini`);
}

// Show Vehicle Details
function showVehicleDetails() {
    document.querySelector('.stats-cards').style.display = 'none';
    document.getElementById('vehicleDetails').style.display = 'block';
    document.getElementById('arrivalDetails').style.display = 'none';
}

// Show Vehicle Passengers
function showVehiclePassengers(vehicleCode) {
    const vehicle = appData.vehicles.find(v => v.code === vehicleCode);
    if (vehicle) {
        let passengerList = `<h4>Penumpang ${vehicleCode}</h4>`;
        
        if (vehicle.passengers.length === 0) {
            passengerList += '<p>Belum ada penumpang</p>';
        } else {
            passengerList += '<ul>';
            vehicle.passengers.forEach(passengerNik => {
                const passenger = appData.participants.find(p => p.nik === passengerNik);
                if (passenger) {
                    passengerList += `<li>${passenger.name} (${passenger.nik})</li>`;
                }
            });
            passengerList += '</ul>';
        }
        
        showModal('Daftar Penumpang', passengerList);
    }
}

// Hide Region Details
function hideRegionDetails() {
    document.querySelector('.stats-cards').style.display = 'grid';
    document.getElementById('regionDetails').style.display = 'none';
    document.getElementById('arrivalDetails').style.display = 'block';
}

// Hide Vehicle Details
function hideVehicleDetails() {
    document.querySelector('.stats-cards').style.display = 'grid';
    document.getElementById('vehicleDetails').style.display = 'none';
    document.getElementById('arrivalDetails').style.display = 'block';
}

// Admin Functions
function loadAdminData() {
    // Load admin data
    // This would typically call GAS backend
}

function showAdminTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.admin-tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all tab buttons
    document.querySelectorAll('.admin-tab').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(`admin${tabName.charAt(0).toUpperCase() + tabName.slice(1)}Tab`).classList.add('active');
    
    // Activate tab button
    event.target.classList.add('active');
}

function addNewUser() {
    showModal('Tambah User Baru', `
        <form id="addUserForm">
            <div class="form-group">
                <label>NIK</label>
                <input type="text" id="newUserNik" required>
            </div>
            <div class="form-group">
                <label>Nama</label>
                <input type="text" id="newUserName" required>
            </div>
            <div class="form-group">
                <label>Region</label>
                <select id="newUserRegion" required>
                    <option value="">Pilih Region</option>
                    ${appData.regions.map(region => `<option value="${region}">${region}</option>`).join('')}
                </select>
            </div>
            <div class="form-group">
                <label>Estate</label>
                <select id="newUserEstate" required>
                    <option value="">Pilih Estate</option>
                    ${appData.estates.map(estate => `<option value="${estate}">${estate}</option>`).join('')}
                </select>
            </div>
            <div class="form-group">
                <label>Role</label>
                <select id="newUserRole" required>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <button type="submit" class="btn-primary">Simpan</button>
        </form>
    `);
    
    document.getElementById('addUserForm').addEventListener('submit', function(e) {
        e.preventDefault();
        // Add user logic here
        showNotification('User berhasil ditambahkan', 'success');
        closeModal();
    });
}

function addNewVehicle() {
    showModal('Tambah Kendaraan Baru', `
        <form id="addVehicleForm">
            <div class="form-group">
                <label>Kode Kendaraan</label>
                <input type="text" id="newVehicleCode" required>
            </div>
            <div class="form-group">
                <label>Jenis</label>
                <select id="newVehicleType" required>
                    <option value="Dinas">Dinas</option>
                    <option value="Pribadi">Pribadi</option>
                    <option value="Sewa">Sewa</option>
                </select>
            </div>
            <div class="form-group">
                <label>Kapasitas</label>
                <input type="number" id="newVehicleCapacity" min="1" required>
            </div>
            <div class="form-group">
                <label>Pengemudi</label>
                <input type="text" id="newVehicleDriver" required>
            </div>
            <div class="form-group">
                <label>Barcode</label>
                <input type="text" id="newVehicleBarcode" required>
            </div>
            <button type="submit" class="btn-primary">Simpan</button>
        </form>
    `);
    
    document.getElementById('addVehicleForm').addEventListener('submit', function(e) {
        e.preventDefault();
        // Add vehicle logic here
        showNotification('Kendaraan berhasil ditambahkan', 'success');
        closeModal();
    });
}

function changePassword() {
    const oldPassword = document.getElementById('oldPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    if (!oldPassword || !newPassword || !confirmPassword) {
        showNotification('Harap isi semua field', 'error');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        showNotification('Password baru tidak cocok', 'error');
        return;
    }
    
    if (newPassword.length < 6) {
        showNotification('Password minimal 6 karakter', 'error');
        return;
    }
    
    const btn = event.target;
    const btnText = btn.querySelector('.btn-text');
    const btnSpinner = btn.querySelector('.btn-spinner');
    
    btnText.style.display = 'none';
    btnSpinner.style.display = 'block';
    btn.classList.add('processing');
    btn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // In production, this would call GAS backend with hash implementation
        showNotification('Password berhasil diubah', 'success');
        
        // Clear form
        document.getElementById('oldPassword').value = '';
        document.getElementById('newPassword').value = '';
        document.getElementById('confirmPassword').value = '';
        
        // Reset button
        btnText.style.display = 'block';
        btnSpinner.style.display = 'none';
        btn.classList.remove('processing');
        btn.disabled = false;
    }, 1500);
}

// Utility Functions
function formatTime(date) {
    if (!date) return '-';
    
    const d = new Date(date);
    return d.toLocaleTimeString('id-ID', { 
        hour: '2-digit', 
        minute: '2-digit',
        day: '2-digit',
        month: 'short'
    });
}

function showNotification(message, type = 'info') {
    const container = document.getElementById('notificationContainer');
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 
                         type === 'error' ? 'exclamation-circle' : 
                         type === 'warning' ? 'exclamation-triangle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(notification);
    
    // Show notification
    setTimeout(() => notification.classList.add('show'), 10);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}

function showLoading() {
    // Create loading overlay if not exists
    let loadingOverlay = document.getElementById('loadingOverlay');
    if (!loadingOverlay) {
        loadingOverlay = document.createElement('div');
        loadingOverlay.id = 'loadingOverlay';
        loadingOverlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9998;
        `;
        
        const spinner = document.createElement('div');
        spinner.className = 'spinner';
        spinner.style.width = '60px';
        spinner.style.height = '60px';
        
        loadingOverlay.appendChild(spinner);
        document.body.appendChild(loadingOverlay);
    }
    
    loadingOverlay.style.display = 'flex';
}

function hideLoading() {
    const loadingOverlay = document.getElementById('loadingOverlay');
    if (loadingOverlay) {
        loadingOverlay.style.display = 'none';
    }
}

function showModal(title, content) {
    // Create modal if not exists
    let modal = document.getElementById('customModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'customModal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        `;
        
        const modalContent = document.createElement('div');
        modalContent.style.cssText = `
            background: white;
            border-radius: var(--border-radius);
            padding: 30px;
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        `;
        
        modalContent.id = 'modalContent';
        modal.appendChild(modalContent);
        document.body.appendChild(modal);
        
        // Close modal on background click
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });
    }
    
    const modalContent = document.getElementById('modalContent');
    modalContent.innerHTML = `
        <h2 style="margin-bottom: 20px; color: var(--primary-color);">${title}</h2>
        <div>${content}</div>
        <div style="text-align: right; margin-top: 20px;">
            <button onclick="closeModal()" class="btn-secondary">Tutup</button>
        </div>
    `;
    
    modal.style.display = 'flex';
}

function closeModal() {
    const modal = document.getElementById('customModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Logout Function
function logout() {
    if (confirm('Apakah Anda yakin ingin logout?')) {
        // Clear session
        localStorage.removeItem('kmp1_fg_session');
        
        // Reset app state
        currentUser = null;
        userSession = null;
        
        // Switch to login page
        document.getElementById('mainApp').style.display = 'none';
        document.getElementById('loginPage').style.display = 'block';
        
        // Clear login form
        document.getElementById('nik').value = '';
        document.getElementById('password').value = '';
        
        showNotification('Anda telah logout', 'info');
    }
}

// Prevent double form submissions
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn && submitBtn.classList.contains('processing')) {
                e.preventDefault();
                return false;
            }
        });
    });
});